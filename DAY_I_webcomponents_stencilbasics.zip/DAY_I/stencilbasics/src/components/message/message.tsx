import { Component, h, Prop, Host } from '@stencil/core';
@Component({
  tag: 'uc-message',
  styleUrl: 'message.styles.css',
})
export class Message {
  //   @Prop() msg: string;
  //   @Prop() from: string;
  //   @Prop() to: string;
  //   @Prop() emoticon: string;

  @Prop() msgDetails: any;
  render() {
    return (
      <Host class="col-md-3">
        <div class="msg-card">
          <h2>{this.msgDetails.msg}</h2>
          <img src={this.msgDetails.emoticon} alt={this.msgDetails.msg} />
          <p>
            {' '}
            <strong>From : {this.msgDetails.from}</strong> - <strong>To : {this.msgDetails.to}</strong>
          </p>
        </div>
      </Host>
    );
  }
}
