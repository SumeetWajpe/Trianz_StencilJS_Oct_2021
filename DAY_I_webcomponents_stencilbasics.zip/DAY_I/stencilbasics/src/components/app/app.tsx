import { Component, h } from '@stencil/core';
@Component({
  tag: 'uc-app',
})
export class App {
  messageOne: any = { msg: 'Hello', from: 'Amit', to: 'Ajay', emoticon: 'https://media.tenor.com/images/707b45bd64095f11b9a93e23eb08c410/tenor.png' };
  messageTwo: any = { msg: 'Hey', from: 'Kunal', to: 'Krunal', emoticon: 'http://2.bp.blogspot.com/-fVP-R_KBZ0o/VcezUD6IgqI/AAAAAAAAQh8/-PhnXRwm0hw/s1600/hey-there.png' };
  messageThree: any = { msg: 'Hola', from: 'Aman', to: 'Amit', emoticon: 'https://i.pinimg.com/originals/f2/db/4f/f2db4f2c239d0f0fe85980b51c92110b.jpg' };
  messageFour: any = { msg: 'Hola', from: 'Nimesh', to: 'John', emoticon: 'https://i.pinimg.com/originals/f2/db/4f/f2db4f2c239d0f0fe85980b51c92110b.jpg' };

  render() {
    return (
      <div class="row">
        <uc-message msgDetails={this.messageOne}></uc-message>
        <uc-message msgDetails={this.messageTwo}></uc-message>
        <uc-message msgDetails={this.messageThree}></uc-message>
        <uc-message msgDetails={this.messageFour}></uc-message>
      </div>
    );
  }
}
