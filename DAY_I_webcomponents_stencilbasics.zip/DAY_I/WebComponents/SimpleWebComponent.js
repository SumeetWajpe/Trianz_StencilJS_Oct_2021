// define the web component
class HelloWorld extends HTMLElement {
  constructor() {
    super();
    console.log("Hello World Instance created !");
  }
}

//register
customElements.define("uc-helloworld", HelloWorld);
