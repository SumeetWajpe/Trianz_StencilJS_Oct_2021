class Tooltip extends HTMLElement {
  tooltip = null;
  tooltipText = "Dummy Tooltip";
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    if (this.hasAttribute("text")) {
      this.tooltipText = this.getAttribute("text");
    }

    this.style.position = "relative";
    this.style.cursor = "pointer";

    const toolTipIcon = document.createElement("span");
    toolTipIcon.innerText = "(?)";
    toolTipIcon.addEventListener("mouseenter", this.showTooltip.bind(this));
    toolTipIcon.addEventListener("mouseleave", this.hideTooltip.bind(this));

    this.shadowRoot.appendChild(toolTipIcon);
  }

  showTooltip() {
    this.tooltip = document.createElement("div");
    this.tooltip.innerText = this.tooltipText;
    this.tooltip.style.position = "absolute";
    this.tooltip.style.left = "10px";
    this.tooltip.style.top = "-10px";
    this.tooltip.style.width = "150px";
    this.tooltip.style.fontFamily = "Verdana";
    this.tooltip.style.fontSize = "8px";
    this.tooltip.style.backgroundColor = "black";
    this.tooltip.style.color = "white";
    this.tooltip.style.padding = "3px ";
    this.tooltip.style.border = "2px solid grey";
    this.tooltip.style.borderRadius = "3px";

    this.shadowRoot.appendChild(this.tooltip);
  }
  hideTooltip() {
    this.shadowRoot.removeChild(this.tooltip);
  }
}

customElements.define("uc-tooltip", Tooltip);
