import { Component, h } from '@stencil/core';

@Component({
  tag: 'my-app',
  styleUrl: 'my-app.css',
})
export class MyApp {
  render() {
    return (
      <div>
        <h1>List Of Courses</h1>
        <list-of-courses></list-of-courses>
      </div>
    );
  }
}
