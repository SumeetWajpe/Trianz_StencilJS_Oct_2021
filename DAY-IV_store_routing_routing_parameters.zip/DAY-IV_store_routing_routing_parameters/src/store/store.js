import { createStore } from '@stencil/store';

let { state } = createStore({ cartItems: [], courses: [], posts: [] });

export default state;
