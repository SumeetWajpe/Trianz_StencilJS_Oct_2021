import { Component, Host, h, Prop, State, EventEmitter, Event } from '@stencil/core';
import state from '../../store/store';
@Component({
  tag: 'app-course',
  styleUrl: 'app-course.css',
})
export class AppCourse {
  @Prop() coursedetails: any;
  @State() currLikes: number;
  @State() isAddedToCart: boolean = false;
  @Event() deleteProduct: EventEmitter<number>;

  constructor() {
    this.currLikes = this.coursedetails.likes;
  }

  IncrementLikes() {
    console.log('U Clicked !');
    //this.coursedetails.likes += 1; // props are immutable !
    // console.log(this.coursedetails.likes);
    this.currLikes++; // state => UI
  }

  AddToCart() {
    this.isAddedToCart = !this.isAddedToCart;
    if (this.isAddedToCart == true) {
      state.cartItems = [...state.cartItems, this.coursedetails];
    } else if (this.isAddedToCart == false) {
      state.cartItems = state.cartItems.filter(i => i.id !== this.coursedetails.id);
    }
  }

  render() {
    let ratings = [];
    for (let index = 0; index < this.coursedetails.rating; index++) {
      ratings.push(<i class="bi bi-star-fill text-warning"></i>);
    }
    return (
      <Host class="col-md-3 my-2">
        <div class={this.isAddedToCart ? 'card p-1 highlight' : 'card p-1'}>
          <img src={this.coursedetails.imageUrl} class="card-img-top" alt={this.coursedetails.title} />
          <div class="card-body">
            {ratings}
            <h5 class="card-title">{this.coursedetails.title}</h5>
            <p class="card-text">
              <strong>Price : </strong>₹. {this.coursedetails.price}
            </p>
            {/* <p class="card-text">
              <strong>Comments : </strong> {this.coursedetails.comments.length} {this.coursedetails.comments.length == 1 ? 'comment' : 'comments'}
            </p> */}
            <p class="card-text">
              <button class="btn btn-outline-primary btn-sm" onClick={this.IncrementLikes.bind(this)}>
                {' '}
                <i class="bi bi-hand-thumbs-up-fill"></i> {this.currLikes}
              </button>
              <button class="btn btn-outline-danger btn-sm mx-1" onClick={() => this.deleteProduct.emit(this.coursedetails.id)}>
                <i class="bi bi-trash2-fill"></i>
              </button>

              <span class="addToCart">
                <input type="checkbox" id="addToCart" onChange={this.AddToCart.bind(this)} /> <label>Add to cart</label>
              </span>
            </p>
          </div>
        </div>
      </Host>
    );
  }
}
