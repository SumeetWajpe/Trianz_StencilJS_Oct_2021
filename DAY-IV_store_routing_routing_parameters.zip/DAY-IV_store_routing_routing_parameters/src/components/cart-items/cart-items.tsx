import { Component, h } from '@stencil/core';
import state from '../../store/store';
@Component({
  tag: 'cart-items',
  styleUrl: 'cart-items.css',
})
export class CartItems {
  render() {
    return (
      <button class="btn btn-warning my-1">
        <i class="bi bi-cart4"></i> <span class="badge bg-primary">{state.cartItems.length}</span>
      </button>
    );
  }
}
