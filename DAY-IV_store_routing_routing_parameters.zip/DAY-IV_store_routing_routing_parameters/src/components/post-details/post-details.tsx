import { Component, h, Prop, State } from '@stencil/core';
import { MatchResults, RouterHistory } from '@stencil/router';

@Component({
  tag: 'post-details',
  styleUrl: 'post-details.css',
})
export class PostDetails {
  @Prop() match: MatchResults;
  @Prop() history: RouterHistory;
  @State() thePost: any = {}; // use strong typed model (Post)

  componentWillLoad() {
    let {
      params: { id },
    } = this.match;

    fetch('https://jsonplaceholder.typicode.com/posts/' + id)
      .then(response => response.json())
      .then(data => (this.thePost = data));
  }

  render() {
    return (
      <div>
        <h1>Post Details for {this.match.params.id}</h1>
        <h4>Body : {this.thePost.body}</h4>
        <h4>Title : {this.thePost.title}</h4>
        <button type="button" class="btn btn-primary" onClick={() => this.history.goBack()}>
          {' '}
          <i class="bi bi-arrow-left"></i> Go Back{' '}
        </button>
        <button class="btn btn-primary mx-2" 
        onClick={() => this.history.push('/newcourse', { msg: 'From Post Details' })}>
          Go to New Course
        </button>
      </div>
    );
  }
}
