import { Component, State, h, Prop } from '@stencil/core';
import { RouterHistory } from '@stencil/router';
import Course from '../../models/course.model';

@Component({
  tag: 'new-course',
  styleUrl: 'new-course.css',
  // shadow: true,
})
export class NewCourse {
  @Prop() history: RouterHistory;

  @State() newCourse: Course = new Course();

  handleSubmit(e) {
    e.preventDefault();
    // get the form values
    // and post to server

    // console.log(this.newCourse);
    //this.courses.push(this.newCourse); // not reflect the changes in Ui as changes made to same object
    // OR
    // this.courses = [...this.courses, this.newCourse];
    e.target.reset();
  }
  render() {
    return (
      <form class="col-md-4" onSubmit={e => this.handleSubmit(e)}>
        {/* <h5>You came : {this.history.location.state.msg}</h5> */}
        <label htmlFor="txtCourseId">Id : </label> <input type="text" required id="txtCourseId" onInput={(e: any) => (this.newCourse.id = e.target.value)} class="form-control" />
        <label htmlFor="txtCourseTitle">Title : </label>{' '}
        <input type="text" id="txtCourseTitle" onInput={(e: any) => (this.newCourse.title = e.target.value)} class="form-control" />
        <label htmlFor="txtCoursePrice">Price : </label>{' '}
        <input type="number" id="txtCoursePrice" onInput={(e: any) => (this.newCourse.price = +e.target.value)} class="form-control" />
        <label htmlFor="txtCourseRating">Rating : </label>{' '}
        <input type="number" id="txtCourseRating" min="1" max="5" onInput={(e: any) => (this.newCourse.rating = +e.target.value)} class="form-control" />
        <label htmlFor="txtCourseLikes">Likes : </label>{' '}
        <input type="number" id="txtCourseLikes" onInput={(e: any) => (this.newCourse.likes = +e.target.value)} class="form-control" />
        <label htmlFor="txtCourseImageUrl">Image Url : </label>{' '}
        <input type="text" id="txtCourseImageUrl" onInput={(e: any) => (this.newCourse.imageUrl = e.target.value)} class="form-control" />
        <input type="submit" value="Add New Course" class="btn btn-success my-1" />
      </form>
    );
  }
}
