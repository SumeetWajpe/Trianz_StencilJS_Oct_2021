import { Component, h } from '@stencil/core';

@Component({
  tag: 'menu-bar',
  styleUrl: 'menu-bar.css',
})
export class MenuBar {
  render() {
    return (
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <slot name="title"></slot>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <slot name="actions"></slot>
          </div>
        </div>
      </nav>
    );
  }
}
