import { Component, h } from '@stencil/core';

@Component({
  tag: 'my-app',
  styleUrl: 'my-app.css',
})
export class MyApp {
  render() {
    return (
      <div>
        {/* <list-of-courses></list-of-courses> */}
        {/* <app-posts></app-posts> */}
        {/* <get-post-by-id></get-post-by-id> */}
        {/* <get-post-by-id-shadow></get-post-by-id-shadow> */}
        {/* <get-post-by-id-ref></get-post-by-id-ref> */}

        <menu-bar>
          <a slot="title" class="navbar-brand" href="/">
            My Online Training App
          </a>
          <ul class="navbar-nav" slot="actions">
            <li class="nav-item">
              <stencil-route-link url="/" class="nav-link">
                Courses
              </stencil-route-link>
            </li>
            <li class="nav-item">
              <stencil-route-link url="/newcourse" class="nav-link">
                New Course
              </stencil-route-link>
            </li>
            <li class="nav-item">
              <stencil-route-link url="/posts" class="nav-link">
                Posts
              </stencil-route-link>
            </li>
            <li class="nav-item">
              <stencil-route-link url="/getpostbyid" class="nav-link">
                Get Post By Id
              </stencil-route-link>
            </li>
          </ul>
        </menu-bar>

        <stencil-router>
          <stencil-route-switch>
            <stencil-route url="/" component="list-of-courses" exact></stencil-route>
            <stencil-route url="/newcourse" component="new-course"></stencil-route>
            <stencil-route url="/posts" component="app-posts"></stencil-route>
            <stencil-route url="/postdetails/:id" component="post-details"></stencil-route>
            <stencil-route url="/getpostbyid" component="get-post-by-id"></stencil-route>
            <stencil-route component="app-error"></stencil-route> {/* written Last  */}
          </stencil-route-switch>
        </stencil-router>
      </div>
    );
  }
}
