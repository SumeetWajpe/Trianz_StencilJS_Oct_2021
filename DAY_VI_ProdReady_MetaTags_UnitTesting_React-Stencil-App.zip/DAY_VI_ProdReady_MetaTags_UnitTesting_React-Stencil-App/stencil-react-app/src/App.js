import logo from "./logo.svg";
import "./App.css";

function App() {
  let cd = {
    id: 1,
    title: "React",
    price: 5000,
    likes: 400,
    rating: 5,
    imageUrl:
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
    comments: [{ id: 1, comment: "Very Good" }],
  };
  return (
    <div className="container">
      <cart-items></cart-items>
    </div>
  );
}

export default App;
