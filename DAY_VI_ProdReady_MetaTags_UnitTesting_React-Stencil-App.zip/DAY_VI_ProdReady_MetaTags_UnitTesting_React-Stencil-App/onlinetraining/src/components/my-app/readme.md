# my-app



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- [menu-bar](../menu-bar)
- stencil-route-link
- stencil-router
- stencil-route-switch
- stencil-route

### Graph
```mermaid
graph TD;
  my-app --> menu-bar
  my-app --> stencil-route-link
  my-app --> stencil-router
  my-app --> stencil-route-switch
  my-app --> stencil-route
  style my-app fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
