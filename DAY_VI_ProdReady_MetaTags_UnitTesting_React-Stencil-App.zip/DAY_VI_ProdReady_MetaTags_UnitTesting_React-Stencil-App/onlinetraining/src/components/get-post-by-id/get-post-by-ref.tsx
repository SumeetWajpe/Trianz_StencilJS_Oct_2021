import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'get-post-by-id-ref',
  styleUrl: 'get-post-by-id.css',
})
export class GetPostByIdRef {
  postInput: HTMLInputElement;
  @State() thePost: any = {};
  getPostById(e) {
    e.preventDefault();
    let thePostId = this.postInput.value;
    fetch('https://jsonplaceholder.typicode.com/posts/' + thePostId)
      .then(response => response.json())
      .then(data => (this.thePost = data));
  }
  render() {
    return (
      <form onSubmit={e => this.getPostById(e)}>
        <div class="postContainer">
          Enter Post Id : <input type="text" ref={element => (this.postInput = element)} />
          <button type="submit">Get Post !</button>
        </div>
        <div class="postData">{this.thePost.title}</div>
      </form>
    );
  }
}
