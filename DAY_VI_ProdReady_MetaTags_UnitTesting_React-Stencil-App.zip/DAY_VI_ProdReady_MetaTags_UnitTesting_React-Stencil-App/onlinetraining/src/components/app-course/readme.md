# app-course



<!-- Auto Generated Below -->


## Properties

| Property        | Attribute       | Description | Type  | Default     |
| --------------- | --------------- | ----------- | ----- | ----------- |
| `coursedetails` | `coursedetails` |             | `any` | `undefined` |


## Events

| Event           | Description | Type                  |
| --------------- | ----------- | --------------------- |
| `deleteProduct` |             | `CustomEvent<number>` |


## Dependencies

### Used by

 - [list-of-courses](../list-of-courses)
 - [list-of-courses-newcourse](../list-of-courses)

### Graph
```mermaid
graph TD;
  list-of-courses --> app-course
  list-of-courses-newcourse --> app-course
  style app-course fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
