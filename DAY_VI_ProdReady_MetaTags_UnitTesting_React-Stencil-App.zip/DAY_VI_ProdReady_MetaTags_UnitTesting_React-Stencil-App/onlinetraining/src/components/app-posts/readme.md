# app-posts



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- stencil-route-link

### Graph
```mermaid
graph TD;
  app-posts --> stencil-route-link
  style app-posts fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
