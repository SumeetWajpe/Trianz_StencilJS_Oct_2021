# menu-bar



<!-- Auto Generated Below -->


## Dependencies

### Used by

 - [my-app](../my-app)

### Graph
```mermaid
graph TD;
  my-app --> menu-bar
  style menu-bar fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
