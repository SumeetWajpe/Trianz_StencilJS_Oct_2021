import { Component, h, Listen } from '@stencil/core';
import appState from '../../store/store';
@Component({
  tag: 'list-of-courses',
  styleUrl: 'list-of-courses.css',
})
export class ListOfCourses {
  // get this data from server !
  // @State() courses: Course[] = [];

  @Listen('deleteProduct')
  DeleteCourse(evt) {
    let theId = evt.detail;
    // splice
    // filter
    appState.courses = appState.courses.filter(function (c) {
      return c.id !== theId;
    });
  }

  // componentWillLoad() {
  //   fetch('http://localhost:5000/courses')
  //     .then(response => response.json())
  //     .then(data => (this.courses = data));
  // }

  render() {
    let coursesToBeRendered = appState.courses.map(function (course) {
      return <app-course key={course.id} coursedetails={course}></app-course>;
    });
    return (
      <div class="row">
        <div class="col-md-2 offset-md-10">
          {' '}
          <cart-items></cart-items>
        </div>
        <h1>List Of Courses</h1>
        <label htmlFor="txtSearchCourse">Search Course Here : </label> <input type="search" id="txtSearchCourse" class="form-control" />
        {coursesToBeRendered}
      </div>
    );
  }
}
