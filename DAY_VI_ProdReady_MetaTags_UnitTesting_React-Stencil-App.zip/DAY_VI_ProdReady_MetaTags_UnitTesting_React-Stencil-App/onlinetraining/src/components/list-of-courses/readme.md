# list-of-courses-newcourse



<!-- Auto Generated Below -->


## Dependencies

### Depends on

- [app-course](../app-course)

### Graph
```mermaid
graph TD;
  list-of-courses-newcourse --> app-course
  style list-of-courses-newcourse fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
