# cart-items



<!-- Auto Generated Below -->


## Dependencies

### Used by

 - [list-of-courses](../list-of-courses)

### Depends on

- stencil-route-link

### Graph
```mermaid
graph TD;
  cart-items --> stencil-route-link
  list-of-courses --> cart-items
  style cart-items fill:#f9f,stroke:#333,stroke-width:4px
```

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
