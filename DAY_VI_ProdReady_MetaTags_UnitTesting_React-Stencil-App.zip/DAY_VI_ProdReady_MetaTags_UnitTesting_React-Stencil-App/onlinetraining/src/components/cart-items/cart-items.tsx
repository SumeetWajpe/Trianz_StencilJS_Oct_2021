import { Component, h } from '@stencil/core';
import state from '../../store/store';
@Component({
  tag: 'cart-items',
  styleUrl: 'cart-items.css',
})
export class CartItems {
  render() {
    let content;
    if (state.cartItems.length > 0) {
      content = (
        <stencil-route-link url="/order-summary">
          <span class="badge bg-primary">{state.cartItems.length}</span>
        </stencil-route-link>
      );
    } else {
      content = <span class="badge bg-primary">{state.cartItems.length}</span>;
    }
    return (
      <button class="btn btn-warning my-1">
        <i class="bi bi-cart4"></i> {content}
      </button>
    );
  }
}
