import { newSpecPage } from '@stencil/core/testing';
import { CartItems } from '../cart-items/cart-items';

describe('Tests for cart-items', () => {
  it('should generate initial count as zero', async () => {
    const { root } = await newSpecPage({
      components: [CartItems],
      html: `<cart-items></cart-items>`,
    });

    expect(root).toEqualHtml(`
    <cart-items>
        <button class="btn btn-warning my-1">
            <i class="bi bi-cart4"></i> <span class="badge bg-primary">0</span>
        </button>
    </cart-items>
    `);
  });

  it('should generate count as one', async () => {
    const { root } = await newSpecPage({
      components: [CartItems],
      html: `<cart-items count="1"></cart-items>`,
    });

    expect(root).toEqualHtml(`
    <cart-items count="1">
        <button class="btn btn-warning my-1">
            <i class="bi bi-cart4"></i><stencil-route-link url="/order-summary">
            <span class="badge bg-primary">1</span>
          </stencil-route-link>
        </button>
    </cart-items>
    `);
  });
});
