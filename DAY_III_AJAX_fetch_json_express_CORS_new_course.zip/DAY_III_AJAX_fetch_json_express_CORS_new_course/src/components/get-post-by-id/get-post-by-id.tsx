import { Component, Host, h, Element, State } from '@stencil/core';

@Component({
  tag: 'get-post-by-id',
  styleUrl: 'get-post-by-id.css',
  // shadow: true,
})
export class GetPostById {
  @Element() el: HTMLElement;
  @State() thePost: any = {};
  getPostById(e) {
    e.preventDefault();
    let thePostId = (this.el.querySelector('#txtPostId') as HTMLInputElement).value;
    fetch('https://jsonplaceholder.typicode.com/posts/' + thePostId)
      .then(response => response.json())
      .then(data => (this.thePost = data));
  }
  render() {
    return (
      <form onSubmit={e => this.getPostById(e)}>
        <div class="postContainer">
          Enter Post Id : <input type="text" id="txtPostId" />
          <button type="submit">Get Post !</button>
        </div>
        <div class="postData">{this.thePost.title}</div>
      </form>
    );
  }
}
