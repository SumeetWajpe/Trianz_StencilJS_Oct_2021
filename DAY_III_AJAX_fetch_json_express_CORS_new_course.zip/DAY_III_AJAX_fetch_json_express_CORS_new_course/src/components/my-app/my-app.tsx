import { Component, h } from '@stencil/core';

@Component({
  tag: 'my-app',
  styleUrl: 'my-app.css',
})
export class MyApp {
  render() {
    return (
      <div>
        <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark">
          <div class="container-fluid">
            <a class="navbar-brand" href="#">
              Online Training
            </a>
            <button
              class="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" aria-current="page" href="#">
                    Courses
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    New Course
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    Posts
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    Get Post By Id
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <list-of-courses></list-of-courses>
        {/* <app-posts></app-posts> */}
        {/* <get-post-by-id></get-post-by-id> */}
        {/* <get-post-by-id-shadow></get-post-by-id-shadow> */}
        {/* <get-post-by-id-ref></get-post-by-id-ref> */}
      </div>
    );
  }
}
