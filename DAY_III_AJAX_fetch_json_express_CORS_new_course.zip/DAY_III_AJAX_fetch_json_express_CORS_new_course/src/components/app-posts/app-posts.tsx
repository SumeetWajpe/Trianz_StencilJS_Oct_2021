import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'app-posts',
  styleUrl: 'app-posts.css',
})
export class AppPosts {
  @State() allPosts: any = [];
  componentWillLoad() {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => (this.allPosts = data));
  }
  render() {
    let postsToBeCreated = this.allPosts.map(post => (
      <li key={post.id} class="list-group-item">
        {post.title}
      </li>
    ));
    return (
      <div>
        <h1>All Posts</h1>
        <ul class="list-group">{this.allPosts.length ? postsToBeCreated : <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />}</ul>
      </div>
    );
  }
}
