import { Component, Host, h, Prop } from '@stencil/core';

@Component({
  tag: 'app-course',
  styleUrl: 'app-course.css',
})
export class AppCourse {
  @Prop() coursedetails: any;
  render() {
    return (
      <Host class="col-md-4">
        <h5>{this.coursedetails.title}</h5>
      </Host>
    );
  }
}
