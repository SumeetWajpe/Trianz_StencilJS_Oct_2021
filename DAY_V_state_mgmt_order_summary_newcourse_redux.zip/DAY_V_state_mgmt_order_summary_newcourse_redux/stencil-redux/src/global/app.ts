import '@ionic/core';
// import { setupConfig } from '@ionic/core';

export default () => {
  // setupConfig({
  //   mode: 'ios'
  // });
};
