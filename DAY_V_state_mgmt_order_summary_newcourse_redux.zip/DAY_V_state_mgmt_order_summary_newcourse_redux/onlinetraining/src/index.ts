export { Components, JSX } from './components';
import '@stencil/router'; // making stencil aware of router
