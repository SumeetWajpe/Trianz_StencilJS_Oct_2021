export default class Course {
  constructor(public id?: number, public title?: string, public price?: number, public rating?: number, public likes?: number, public imageUrl?: string, public comments?: any) {}
}
