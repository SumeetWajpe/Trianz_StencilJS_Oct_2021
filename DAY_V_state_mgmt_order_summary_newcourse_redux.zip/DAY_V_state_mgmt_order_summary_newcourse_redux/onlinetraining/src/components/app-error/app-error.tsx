import { Component, h } from '@stencil/core';

@Component({
  tag: 'app-error',
  styleUrl: 'app-error.css',
  shadow: true,
})
export class AppError {
  render() {
    return (
      <div>
        <img src="http://www.setra.com/hubfs/Sajni/crc_error.jpg" />
        <h1>Something went wrong !</h1>
      </div>
    );
  }
}
