import { Component, Host, h } from '@stencil/core';
import appState from '../../store/store';
@Component({
  tag: 'order-summary',
  styleUrl: 'order-summary.css',
  // shadow: true,
})
export class OrderSummary {
  render() {
    let itemsInCart = appState.cartItems.map(course => (
      <div class="card mb-3">
        <div class="row g-0">
          <div class="col-md-4">
            <img src={course.imageUrl} class="img-fluid rounded-start" alt={course.title} />
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">{course.title}</h5>
              <p class="card-text">{course.price}</p>
            </div>
          </div>
        </div>
      </div>
    ));
    return (
      <div>
        <h2>Order Summary</h2>
        {itemsInCart}
      </div>
    );
  }
}
